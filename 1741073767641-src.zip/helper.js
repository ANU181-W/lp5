const httpClient = require("./httpClient");

const helper = {};

helper.saveErrorInAws = async (error) => {
  await httpClient.post(process.env.LOGGER_SERVICE, { message: error });
};

module.exports = helper;
