const axios = require("axios");

const httpClient = {};

const getConfig = (token) => ({
  headers: { Authorization: `Bearer ${token}` },
});

httpClient.get = async (url, token) => axios.get(url, getConfig(token));

httpClient.post = async (url, options, token) =>
  axios.post(url, options, getConfig(token));

httpClient.remove = async (url, options, token) =>
  axios.delete(url, options, getConfig(token));

module.exports = httpClient;
