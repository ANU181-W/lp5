const { Schema, model } = require('mongoose');

const feedSchema = new Schema({
  type: {
    type: String,
    required: true
  },
  impression: {
    type: Number,
    default: 0
  },
  videoClicksCount: {
    type: Number,
    default: 0
  },
},
  { strict: false }
);

feedSchema.index({ userId: 1, feed_id: 1, modifiedDate: -1, active: 1 });
feedSchema.index({ modifiedDate: -1 });
feedSchema.index({ feed_id: 1 });


module.exports = model('feed', feedSchema);
