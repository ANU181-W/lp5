const pitchViewModel = {};

pitchViewModel.createViewModel = (req) => {
    const { feed, type } = req.data;
    const { _id: feedId, ...feedWithoutId } = feed;
    const feeddata = {
        feed_id: feedId,
        ...feedWithoutId
    };
    const viewModel = {
        type,
        ...feeddata
    };


    return viewModel;
};


module.exports = pitchViewModel;
