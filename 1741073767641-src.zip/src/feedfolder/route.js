const express = require('express');
const controller = require('./controller')
const router = express.Router();

// router.post('/create', (req, res, next) =>
//     controller
//         .create(req)
//         .then((success) => res.status(200).json(success))
//         .catch((err) => next(err))
// );
// router.post('/delete', (req, res, next) =>
//   controller
//     .delete(req)
//     .then((success) => res.status(200).json(success))
//     .catch((err) => next(err))
// );
// router.post('/update',(req, res, next) =>
//   controller
//     .update(req)
//     .then((success) => res.status(200).json(success))
//     .catch((err) => next(err))
// );
// router.post('/share',(req, res, next) =>
//   controller
//     .share(req)
//     .then((success) => res.status(200).json(success))
//     .catch((err) => next(err))
// );
router.get('/', (req, res) => res.status(200).json({ root: 'ok' }));
router.post('/createFeed', (req, res, next) =>
  controller
    .createFeed(req)
    .then((success) => res.status(200).json(success))
    .catch((err) => next(err))
);
router.get('/getAllFeeds/:pageNumber/:pagePerSize/:dateTime', (req, res, next) =>
  controller
    .getAllFeeds(req)
    .then((success) => res.status(200).json(success))
    .catch((err) => next(err))
);
router.get('/getAlFollowerFeeds/:pageNumber/:pagePerSize/:dateTime', (req, res, next) =>
  controller
    .getAlFollowerFeeds(req)
    .then((success) => res.status(200).json(success))
    .catch((err) => next(err))
);
router.get('/getfeedByUserId/:userId/:pageNumber/:pagePerSize', (req, res, next) =>
  controller
    .getFeedById(req)
    .then((success) => res.status(200).json(success))
    .catch((err) => next(err))
);
router.get('/getfeeData/:userId/:startTime1', (req, res, next) =>
  controller
    .getfeeData(req)
    .then((success) => res.status(200).json(success))
    .catch((err) => next(err))
);

router.get('/getFeedByHighestImpression/:pageNumber/:pagePerSize', (req, res, next) =>
  controller
    .getFeedByHighestImpression(req)
    .then((success) => res.status(200).json(success))
    .catch((err) => next(err))
);

router.post('/updateVideoClickCount', (req, res, next) =>
  controller
    .updateVideoClickCount(req)
    .then((success) => res.status(200).json(success))
    .catch((err) => next(err))
);

router.post('/multiplePitchByIds', (req, res, next) =>
  controller
    .multiplePitchByIds(req)
    .then((success) => res.status(200).json(success))
    .catch((err) => next(err))
);


router.post('/savePost', (req, res, next) => {
  controller
    .savePost(req)
    .then((response) => res.status(200).json(response))
    .catch((err) => next(err));
});

router.delete(
  '/unsavePost/:postId/:userId',
  (req, res, next) => {
    controller
      .unsavePost(req)
      .then((response) => res.status(200).json(response))
      .catch((err) => next(err));
  }
);

router.get(
  '/getAllSavedPosts/:userId/:pageNumber/:pagePerSize',
  (req, res, next) => {
    controller
      .getAllSavedPosts(req)
      .then((response) => res.status(200).json(response))
      .catch((err) => next(err));
  }
);

router.get('/checkSavePost/:userId/:pitchId',
  (req, res, next) => {
    controller
      .checkSavePost(req)
      .then((response) => res.status(200).json({saved:response}))
      .catch((err) => next(err));
})

router.get('/getUserSavedPosts/:userId',
  (req, res, next) => {
    controller
      .getUserSavedPosts(req)
      .then((response) => res.status(200).json({userSavedPosts:response}))
      .catch((err) => next(err));
  }
)

module.exports = router;