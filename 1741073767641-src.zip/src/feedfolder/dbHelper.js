// const apiLogger = require('../config/apiLogger');
const Feed = require("./model");
const mongoClient = require("../../mongodbConnection");
const { ObjectId } = require("mongodb");
const { Types } = require("mongoose");
const SavePost = require("./savepostModel");

const feedDbHelper = {};

const addHasVoted = (result, userId) => {
  for (let i = 0; i < result.length; i += 1) {
    if (result[i].type === "poll") {
      const options = result[i].options;
      result[i].hasVoted = options.some(
        (option) =>
          option.votedUserIds &&
          option.votedUserIds.some((item) => item.userId === userId)
      );
    }
  }
  return result;
};

feedDbHelper.getFeedByHighestImpression = async (skipNumber, numberPerPage) => {
  try {
    return await Feed.find({
      active: true,
    })
      .sort({ impression: -1 })
      .skip(skipNumber)
      .limit(numberPerPage)
      .lean();
  } catch (error) {
    return Promise.reject(error);
  }
};

feedDbHelper.createFeed = async (input) => {
  try {
    const obj = await Feed({ ...input, processed: true });
    return obj.save().then(() => obj);
  } catch (error) {
    return Promise.reject(error);
  }
};

feedDbHelper.updateVideoClickCount = async (pitchId) => {
  try {
    await Feed.updateOne(
      { feed_id: new Types.ObjectId(pitchId) },
      {
        $inc: {
          videoClicksCount: 1,
        },
      }
    );
    return true;
  } catch (err) {
    return Promise.reject(err);
  }
};

feedDbHelper.getOnlyFollowingIdsByUserId = async (userId) => {
  const client = await mongoClient.getClient(process.env.COMMON_HOST);
  const champhunt = client.db(process.env.DB_NAME);
  const id = new Types.ObjectId(userId);
  const result = await champhunt
    .collection("users")
    .find({ _id: id })
    .project({ following: 1, _id: 0 })
    .toArray();
  const userFollowingIds = result[0]?.following?.map(
    (item) => item.followingUserId
  );

  return userFollowingIds;
};

feedDbHelper.updateImpression = async (feedId, impressionCount) => {
  try {
    await Feed.findOneAndUpdate(
      { feed_id: new Types.ObjectId(feedId) },
      { $set: { impression: impressionCount } },
      { new: true }
    );
  } catch (error) {
    return Promise.reject(error);
  }
};

feedDbHelper.getFeedById = async (userId, pageNumber, pagePerSize) => {
  try {
    const result = await Feed.find({
      userId,
      active: true,
    })
      .sort({ createdDate: -1 })
      .skip(pageNumber)
      .limit(pagePerSize)
      .select("-impression -videoClicksCount")
      .lean();
    const newResult = addHasVoted(result, userId);
    return newResult && newResult.length > 0 ? newResult : [];
  } catch (err) {
    return Promise.reject(err);
  }
};

feedDbHelper.runGivenByLoggedInUserIdForPitch = async (
  loggedInUserId,
  pitchId
) => {
  try {
    const client = await mongoClient.getClient(process.env.COMMON_HOST);
    const champhunt = client.db(process.env.DB_NAME);
    const result = await champhunt
      .collection("pitchruns")
      .findOne({ postId: pitchId.toString(), userId: loggedInUserId });
    return result;
  } catch (err) {
    return Promise.reject(err);
  }
};

feedDbHelper.runGivenByLoggedInUserIdForSharejob = async (
  loggedInUserId,
  pitchId
) => {
  try {
    const client = await mongoClient.getClient(process.env.COMMON_HOST);
    const champhunt = client.db(process.env.DB_Champhunt_job);
    const result = await champhunt
      .collection("sharejobruns")
      .findOne({ shareJobId: pitchId.toString(), userId: loggedInUserId });
    return result;
  } catch (error) {
    return Promise.reject(error);
  }
};

feedDbHelper.hasSharedJob = async (_userId, _jobId) => {
  try {
    const client = await mongoClient.getClient(process.env.COMMON_HOST);
    const champhunt = client.db(process.env.DB_Champhunt_job);
    const result = await champhunt.collection("sharejobs").findOne({
      jobId: _jobId,
      userId: _userId,
      active: true,
    });
    return result?._id ? true : false;
  } catch (error) {
    return Promise.reject(error);
  }
};

feedDbHelper.getAllReportedPitch = async (id) => {
  try {
    const client = await mongoClient.getClient(process.env.COMMON_HOST);
    const champhunt = client.db(process.env.DB_NAME);
    const collection = champhunt.collection("pitchreports");
    const result = await collection
      .find({ userId: id })
      .project({ postId: 1, _id: 0 })
      .toArray();
    const reporteduserIDs = result.map((item) => new ObjectId(item.postId));
    return reporteduserIDs;
  } catch (err) {
    return Promise.reject(err);
  }
};

feedDbHelper.getBlockedUsersByUserIDList = async (blockedByUId) => {
  try {
    const client = await mongoClient.getClient(process.env.COMMON_HOST);
    const champhunt = client.db(process.env.DB_NAME);
    const result = await champhunt
      .collection("blockusers")
      .find({ blockedByUserId: blockedByUId })
      .project({ blockedUserId: 1, _id: 0 })
      .toArray();
    const blockedUserIds = result.map((item) => item.blockedUserId);
    return blockedUserIds;
  } catch (err) {
    return Promise.reject(err);
  }
};

feedDbHelper.getAllFeeds = async (
  skipNumber,
  numberPerPage,
  browseringStartTime,
  reportedPitchID,
  blockedUsersId,
  loggedInUserId
) => {
  try {
    const result = await Feed.find({
      userId: { $nin: blockedUsersId },
      feed_id: { $nin: reportedPitchID },
      modifiedDate: { $lte: new Date(browseringStartTime) },
      active: true,
    })
      .sort({ modifiedDate: -1 })
      .skip(skipNumber)
      .limit(numberPerPage)
      .select("-impression -videoClicksCount")
      .lean();
    return addHasVoted(result, loggedInUserId);
  } catch (err) {
    return Promise.reject(err);
  }
};

feedDbHelper.getAlFollowerFeeds = async (
  userIds,
  skipNumber,
  numberPerPage,
  browseringStartTime,
  reportedPitchID,
  blockedUsersId,
  loggedInUserId
) => {
  try {
    const result = await Feed.find({
      userId: {
        $nin: blockedUsersId,
        $in: userIds,
      },
      feed_id: { $nin: reportedPitchID },
      modifiedDate: { $lte: new Date(browseringStartTime) },
      active: true,
    })
      .sort({ modifiedDate: -1 })
      .skip(skipNumber)
      .limit(numberPerPage)
      .select("-impression -videoClicksCount")
      .lean();

    return addHasVoted(result, loggedInUserId);
  } catch (err) {
    return Promise.reject(err);
  }
};
feedDbHelper.getfeeData = async (userId, startTime1) => {
  try {
    console.log(startTime1);
    const result = await Feed.find({
      userId,
      createdDate: { $gte: new Date(startTime1) },
    });
    console.log(result);
    return result;
  } catch (err) {
    return Promise.reject(err);
  }
};
feedDbHelper.multiplePitchByIds = async (pitchIds) => {
  try {
    let array = [];
    for (let i = 0; i < pitchIds.length; i++) {
      array.push(new Types.ObjectId(pitchIds[i]));
    }
    const result = await Feed.find({ feed_id: { $in: array } });
    console.log("result", result);
    return result;
  } catch (err) {
    return Promise.reject(err);
  }
};

// function to save a post
feedDbHelper.savePost = async ({ postId, userId }) => {
  try {
    // const post = await Pitch.find({ _id: postId });

    // if (!post) {
    //   return {
    //     success: false,
    //     message: 'Post not found or could not be updated.',
    //   };
    // }
    // console.log(post)

    const firstCheckSavedPostCreated = await SavePost.findOne({
      userProfileId: userId,
      savedPostId: postId,
    });

    if (firstCheckSavedPostCreated) {
      firstCheckSavedPostCreated.isSaved = true;
      await firstCheckSavedPostCreated.save();
      return {
        success: true,
        data: firstCheckSavedPostCreated,
      };
    }

    const savePost = new SavePost({
      userProfileId: userId,
      savedPostId: postId,
      isSaved: true,
    });
    await savePost.save();
    return {
      success: true,
      data: savePost,
    };
  } catch (error) {
    return {
      success: false,
      message: error.message,
    };
  }
};

feedDbHelper.unsavePost = async (postId, userId) => {
  try {
    const updatedPost = await SavePost.findOneAndUpdate(
      { savedPostId: postId, userProfileId: userId },
      { $set: { isSaved: false } },
      { new: true }
    );

    if (!updatedPost) {
      return {
        success: false,
        message: "Post not found or could not be updated.",
      };
    }

    return {
      success: true,
      data: updatedPost,
    };
  } catch (err) {
    return {
      success: false,
      message: err.message,
    };
  }
};

// Function to get all saved posts
feedDbHelper.getAllSavedPosts = async (userId, pageNumber, pagePerSize) => {
  try {
    const skipIndex = (pageNumber - 1) * pagePerSize;

    const savedPosts = await SavePost.find({
      userProfileId: userId,
      isSaved: true,
    })
      .populate("savedPostId")
      .sort({ createdDate: -1 })
      .limit(pagePerSize)
      .skip(skipIndex)
      .lean();

    const savedFeedResult = savedPosts.map((savedFeed) => {
      return {
        ...savedFeed.savedPostId,
      };
    });

    return savedFeedResult;
  } catch (err) {
    return Promise.reject(err);
  }
};

feedDbHelper.checkSavePost = async (userId, pitchId) => {
  try {
    const result = await SavePost.findOne({
      userProfileId: userId,
      savedPostId: pitchId,
    });

    return result ? result?.isSaved : false;
  } catch (err) {
    return Promise.reject(err);
  }
};

feedDbHelper.getUserSavedPosts = async (userId) => {
  try {
    const userSavedPosts = await SavePost.find({
      userProfileId: userId,
      isSaved: true
    }).select({
      savedPostId: 1,
    });

    return userSavedPosts.map((post) => {
      return post.savedPostId;
    });
  } catch (err) {
    return Promise.reject(err);
  }
};

module.exports = feedDbHelper;
