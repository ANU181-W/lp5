// const viewModel = require('./viewModel');
const dbHelper = require('./dbHelper');


const feed = {};

feed.createFeed = async (req) => {
  try {
    if (!req.body) return "field required"
    return await dbHelper.createFeed(req.body)
  } catch (error) {
    return Promise.reject(error)
  }
}

feed.getFeedByHighestImpression = async (req) => {
  try {
    const skipNumber = (parseInt(req.params.pageNumber, 10) - 1) * parseInt(req.params.pagePerSize, 10);
    const pagePerSizeValue = parseInt(req.params.pagePerSize, 10);

    return await dbHelper.getFeedByHighestImpression(skipNumber, pagePerSizeValue)
  } catch (error) {
    return Promise.reject(error)
  }
}

feed.updateVideoClickCount = async (req) => {
  try {
    if (req.body.id) {
      await dbHelper.updateVideoClickCount(req.body.id);
      return 'video click count updated!';
    }
    return 'input required!';
  } catch (err) {
    return Promise.reject(err);
  }
};

feed.getAllFeeds = async (req) => {
  try {
    const { pageNumber, pagePerSize, dateTime } = req.params;

    if (!pageNumber && !pagePerSize && !req.headers.userid && !dateTime)
      return [];

    const skipNumber = (parseInt(pageNumber, 10) - 1) * parseInt(pagePerSize, 10);
    const pagePerSizeValue = parseInt(pagePerSize, 10);

    const [reportedPitchID, blockedUsersId, userFollowingIds] = await Promise.all([
      dbHelper.getAllReportedPitch(req.headers.userid),
      dbHelper.getBlockedUsersByUserIDList(req.headers.userid),
      dbHelper.getOnlyFollowingIdsByUserId(req.headers.userid)
    ]);

    const reportedPitchIDArray = reportedPitchID.map((id) => id.postId);

    const pitches = await dbHelper.getAllFeeds(
      skipNumber,
      pagePerSizeValue,
      dateTime.toString(),
      reportedPitchIDArray,
      blockedUsersId,
      req.headers.userid
    );
    if (!pitches || pitches.length === 0) {
      return [];
    }

    const updatedDeals = await Promise.all(
      pitches.map(async (element) => {
        let runsGiven = 0;
        let hasShared = false;
        let accepted = false;
        let rejected = false;
        let isFollowing = false;
        let isSaved = false;
        if (element.type === 'post') {

          if (element.sharedPost && req.headers.userid) {
            hasShared = element.sharedPost.includes(req.headers.userid);
          }

          isFollowing = userFollowingIds.includes(element.userId)
          isSaved = await dbHelper.checkSavePost(req.headers.userid, String(element.feed_id))

          const runs = await dbHelper.runGivenByLoggedInUserIdForPitch(
            req.headers.userid,
            element.feed_id
          );
          runsGiven = runs?.run ? runs?.run : 0;
        } else if (element.type === 'sharejob') {
          const runs = await dbHelper.runGivenByLoggedInUserIdForSharejob(
            req.headers.userid,
            element.feed_id
          );
          runsGiven = runs?.run ? runs?.run : 0;

          hasShared = await dbHelper.hasSharedJob(req.headers.userid, element?.jobId);

        }
        else if (element?.type === 'challenge' && element?.userId !== req.headers.userid) {
          rejected = element?.rejectedUserIds?.includes(req.headers.userid);
          accepted = element?.acceptedUserDetails?.userId === req.headers.userid
        }

        return {
          ...element, runsGiven,
          hasShared,
          rejected,
          accepted,
          isFollowing,
          isSaved
        };
      })
    );
    if (!updatedDeals || updatedDeals.length === 0) {
      return [];
    }

    return updatedDeals;
  } catch (err) {
    return Promise.reject(err);
  }
};

feed.getAlFollowerFeeds = async (req) => {
  try {

    const { pageNumber, pagePerSize, dateTime } = req.params;

    if (!pageNumber && !pagePerSize && !req.headers.userid && !dateTime)
      return [];

    const skipNumber = (parseInt(pageNumber, 10) - 1) * parseInt(pagePerSize, 10);
    const pagePerSizeValue = parseInt(pagePerSize, 10);
    const [userFollowingIds, reportedPitchID, blockedUsersId] = await Promise.all([dbHelper.getOnlyFollowingIdsByUserId(
      req.headers.userid
    ), dbHelper.getAllReportedPitch(req.headers.userid),
    dbHelper.getBlockedUsersByUserIDList(req.headers.userid),
    ]);
    const userIds = [req.headers.userid];
    if (userFollowingIds?.length)
      userIds.push(...userFollowingIds);
    const reportedPitchIDArray = reportedPitchID.map((id) => id.postId);
    const pitches = await dbHelper.getAlFollowerFeeds(
      userIds,
      skipNumber,
      pagePerSizeValue,
      dateTime.toString(),
      reportedPitchIDArray,
      blockedUsersId,
      req.headers.userid
    );
    if (!pitches || pitches.length === 0) {
      return [];
    }

    const updatedDeals = await Promise.all(
      pitches.map(async (element) => {
        let runsGiven = 0;
        let accepted = false;
        let rejected = false;
        let hasShared = false;
        if (element.type === 'post') {
          if (element.sharedPost && req.headers.userid) {
            hasShared = element.sharedPost.includes(req.headers.userid);
          }
          const runs = await dbHelper.runGivenByLoggedInUserIdForPitch(
            req.headers.userid,
            element.feed_id
          );

          runsGiven = runs?.run ? runs?.run : 0;
        } else if (element.type === 'sharejob') {
          const runs = await dbHelper.runGivenByLoggedInUserIdForSharejob(
            req.headers.userid,
            element.feed_id
          );
          runsGiven = runs?.run ? runs?.run : 0;
          hasShared = await dbHelper.hasSharedJob(req.headers.userid, element?.jobId);
        }
        else if (element?.type === 'challenge' && element?.userId !== req.headers.userid) {
          rejected = element?.rejectedUserIds?.includes(req.headers.userid);
          accepted = element?.acceptedUserDetails?.userId === req.headers.userid
        }
        return { ...element, runsGiven, hasShared, rejected, accepted };
      })
    );
    if (!updatedDeals || updatedDeals.length === 0) {
      return [];
    }
    return updatedDeals
  } catch (err) {
    return Promise.reject(err);
  }
};


feed.getFeedById = async (req) => {
  try {
    const { pageNumber, pagePerSize, userId } = req.params;

    if (!pageNumber && !pagePerSize && !userId)
      return [];

    const skipNumber = (parseInt(pageNumber, 10) - 1) * parseInt(pagePerSize, 10);
    const pagePerSizeValue = parseInt(pagePerSize, 10);
    const pitches = await dbHelper.getFeedById(userId, skipNumber, pagePerSizeValue);

    if (!pitches || pitches.length === 0) {
      return [];
    }
    if (req.headers.userid === userId) {
      return pitches;
    }
    const updatedDeals = await Promise.all(
      pitches.map(async (element) => {
        let runsGiven = 0;
        let hasShared = false;
        let accepted = false;
        let rejected = false;
        if (element.type === 'post') {
          if (element.sharedPost && req.headers.userid) {
            hasShared = element.sharedPost.includes(req.headers.userid);
          }
          const runs = await dbHelper.runGivenByLoggedInUserIdForPitch(
            req.headers.userid,
            element.feed_id
          );

          runsGiven = runs?.run ? runs?.run : 0;
        } else if (element.type === 'sharejob') {
          const runs = await dbHelper.runGivenByLoggedInUserIdForSharejob(
            req.headers.userid,
            element.feed_id
          );
          runsGiven = runs?.run ? runs?.run : 0;

        }
        else if (element?.type === 'challenge' && element?.userId !== req.headers.userid) {
          rejected = element?.rejectedUserIds?.includes(req.headers.userid);
          accepted = element?.acceptedUserDetails?.userId === req.headers.userid
        }
        return { ...element, runsGiven, hasShared, rejected, accepted };
      })
    );
    if (!updatedDeals || updatedDeals.length === 0) {
      return [];
    }
    return updatedDeals
  } catch (err) {
    return Promise.reject(err);
  }
};
feed.getfeeData = async (req) => {
  try {
    const { userId, startTime1 } = req.params;
    console.log("startTime1 getfeeData line253", startTime1)


    const originalDateString = startTime1;
    const originalDate = new Date(originalDateString);

    // Format the date in ISO 8601 format
    const iso8601DateString = originalDate.toISOString().replace("Z", "+00:00");
    const data = await dbHelper.getfeeData(userId, iso8601DateString)
    return data;

  } catch (err) {
    return Promise.reject(err);
  }
};
feed.multiplePitchByIds = async (req) => {
  try {
    console.log("pitchIds", req.body.pitchIds)
    const { pitchIds } = req.body;
    if (!pitchIds) return 'field required'
    const data = await dbHelper.multiplePitchByIds(pitchIds)
    return data;
  } catch (err) {
    return Promise.reject(err);
  }
};





feed.savePost = async (req) => {
  try {
    const { postId, userId } = req.body;

    if (!postId || !userId) {
      return {
        success: false,
        message: 'Post ID and User ID are required',
      };
    }

    const response = await dbHelper.savePost({ postId, userId });

    if (response) {
      
      return {
        success: true,
        message: 'Post saved successfully',
        data: response,
      };
    } else {
      throw new Error('Failed to save the post');
    }
  } catch (error) {
    return {
      success: false,
      message: error.message,
    };
  }
};

feed.unsavePost = async (req) => {
  try {
    const { postId, userId } = req.params;

    if (!postId || !userId) {
      return {
        success: false,
        message: 'Post ID and User ID are required',
      };
    }

    const response = await dbHelper.unsavePost(postId, userId);

    if (response.success) {
      return {
        success: true,
        message: 'Post unsaved successfully',
        data: response.data,
      };
    } else {
      throw new Error('Failed to unsave the post');
    }
  } catch (error) {
    return {
      success: false,
      message: error.message,
    };
  }
};


// Function to  getting all saved posts
feed.getAllSavedPosts = async (req) => {
  try {
    const { userId, pageNumber, pagePerSize } = req.params;

    if (!userId) {
      return {
        success: false,
        message: 'User ID is required',
      };
    }

    const page = Number(pageNumber) || 1;
    const perPage = Number(pagePerSize) || 10;

    const response = await dbHelper.getAllSavedPosts(userId, page, perPage);

    if (response) {
      return {
        success: true,
        message: 'Fetched all saved posts successfully',
        data: response,
      };
    } else {
      throw new Error('Failed to fetch saved posts');
    }
  } catch (error) {
    return {
      success: false,
      message: error.message,
    };
  }
};

feed.checkSavePost = async (req) => {
  try{
    const { userId, pitchId } = req.params
    return await dbHelper.checkSavePost(userId, pitchId);
  }catch(err){
    return Promise.reject(err)
  }
}

feed.getUserSavedPosts = async (req) => {
  try{
    const { userId } = req.params
    return await dbHelper.getUserSavedPosts(userId)
  }catch(err){
    return Promise.reject(err)
  }
}

module.exports = feed;