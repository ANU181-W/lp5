const mongoose = require("mongoose")

const savePostSchema = new mongoose.Schema({
    userProfileId: {
        type: String,
        required: true
    },
    savedPostId: {
        type: Object,
        ref : 'feed',
        required: true
    },
    isSaved: {
        type: Boolean,
        default: true
    },
    createdDate: {
        type: Date,
        default: Date.now,
    },
    modifiedDate: {
        type: Date,
        default: Date.now,
    },
})

module.exports = mongoose.model('savePost', savePostSchema)