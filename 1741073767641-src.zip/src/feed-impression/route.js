const express = require('express');
const controller = require('./controller');

const router = express.Router();

router.post(
  '/create',
  (req, res, next) =>
    controller
      .create(
        req
      )
      .then((success) => res.status(200).json(success))
      .catch((err) => next(err))
);

//Post Analytics APIs
router.get(
  '/getFeedImpressionByDate/:feedId/:startDate/:endDate',
  (req, res, next) =>
    controller
      .getImpressionOfFeedIdByDate(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);

router.get(
  '/getEngagementByDate/:feedId/:type/:startDate/:endDate',
  (req, res, next) =>
    controller
      .getEngagementByFeedId(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);

router.get(
  '/getPerformanceByFeedId/:feedId/:type/:startDate/:endDate',
  (req, res, next) =>
    controller
      .getPerformanceByFeedId(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);

//reach denotes unique users who have viewed the post
router.get(
  '/getReachOfFeedId/:feedId/:startDate/:endDate',
  (req, res, next) =>
    controller
      .getReachOfFeedId(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);


//Profile Analytics APIs
router.get(
  '/getProfileImpressionOfUserId/:userId/:startDate/:endDate',
  (req, res, next) =>
    controller
      .getProfileImpressionOfUserId(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);

router.get(
  '/getProfileEngagement/:userId/:startDate/:endDate',
  (req, res, next) =>
    controller
      .getProfileEngagement(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);

router.get(
  '/getProfilePerformanceByUserId/:userId/:startDate/:endDate',
  (req, res, next) =>
    controller
      .getProfilePerformanceByUserId(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);

router.get(
  '/getProfileReachOfUserId/:userId/:startDate/:endDate',
  (req, res, next) =>
    controller
      .getProfileReachOfUserId(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);

router.get(
  '/getAllFeedsImpression/:userId/:startDate/:endDate',
  (req, res, next) =>
    controller
      .getAllFeedsImpression(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);


//Extra APIs

router.get('getEngagementFromFollowers/:feedId/:userId/:type',
  (req, res, next) =>
    controller
      .getEngagementFromFollowers(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err)))

router.get(
  '/getImpressionOfFeedId/:feedId',
  (req, res, next) =>
    controller
      .getImpressionOfFeedId(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err))
);

router.get('getEngagementFromNonFollowers/:feedId/:userId/:type',
  (req, res, next) =>
    controller
      .getEngagementFromNonFollowers(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err)))

router.get('runsReceivedByUserId/:userId/:startDate/:endDate',
  (req, res, next) =>
    controller
      .runsReceivedByUserId(req)
      .then((data) => res.status(200).json(data))
      .catch((err) => next(err)))



module.exports = router;
