const dbClient = require('mongoose');

const feedImpressionSchema = new dbClient.Schema({
  feedId: {
    type: String,
    required: true
  },
  visitedUserId: {
    type: String,
    required: true,
  },
  //latitude,longitude
  visitorLocation: {

  },
  state: {
    type: String,

  },
  country: { type: String, },
  createdDate: {
    type: Date,
    default: Date.now,
  },
  modifiedDate: {
    type: Date,
    default: Date.now,
  },
});

module.exports = dbClient.model('feedimpression', feedImpressionSchema);
