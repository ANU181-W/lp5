const feedImpressionViewModel = {};

feedImpressionViewModel.createViewModel = (
  req
) => {
  const { userid, username } = req.headers
  const { feedId, visitorLocation, state, country } = req.body
  const viewModel = {};
  if (country) {
    viewModel.country = country;
  }
  if (state) {
    viewModel.state = state;
  }
  if (visitorLocation) {
    viewModel.visitorLocation = visitorLocation;
  }
  viewModel.visitedUserId = userid;
  viewModel.userName = username;
  viewModel.feedId = feedId
  return viewModel;
};

module.exports = feedImpressionViewModel;
