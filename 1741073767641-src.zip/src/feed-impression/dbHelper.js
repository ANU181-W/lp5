
const mongoclient = require('../../mongodbConnection');
const FeedImpression = require('./model');
const { Types } = require('mongoose');
const feedImpressionDbHelper = {};
const Feed = require('../feedfolder/model'); 

feedImpressionDbHelper.save = async (dealInput) => {
  try {
    const obj = new FeedImpression(dealInput);
    const response=await obj.save().then(() => obj);
    if(response){
      const impressionCount = await FeedImpression.countDocuments({ feedId: response?.feedId });
      return {response, impressionCount};
    }
    return "No response"
  } catch (err) {
    return Promise.reject(err);
  }
};


feedImpressionDbHelper.getImpressionOfFeedId = async (feedId) => {
  try {
    const count = await FeedImpression.countDocuments({ feedId });
    return count;
  } catch (error) {
    return Promise.reject(error);
  }
};

feedImpressionDbHelper.getReachOfFeedId = async (feedId,startDate,endDate) => {
  try {
    const result = await FeedImpression.aggregate([
      {
        $match: {
          feedId,
          createdDate: { 
            $gte: new Date(startDate), 
            $lte: new Date(new Date(endDate).setDate(new Date(endDate).getDate() + 1)) 
          }        }
      },
      {
        $project: {
          visitedUserId: 1,
          createdDate: -1
        }
      },
      {
        $addFields: {
          date: { $dateToString: { format: "%d/%m", date: "$createdDate" } }
        }
      },
      {
        $group: {
          _id: "$date",
          uniqueVisitors: { $addToSet: "$visitedUserId" },
        },
        
      },{
        $sort: { "_id": 1 }
      }
    ]);
    const sum = result.reduce((acc, curr) => acc + curr.uniqueVisitors.length, 0);
    return {result,sum};
  } catch (error) {
    return Promise.reject(error);
  }
};

feedImpressionDbHelper.getImpressionOfFeedIdByDate = async (feedId, startDate, endDate) => {
  try {
    const result = await FeedImpression.aggregate([
      {
        $match: {
          feedId,
          createdDate: { 
            $gte: new Date(startDate), 
            $lte: new Date(new Date(endDate).setDate(new Date(endDate).getDate() + 1)) 
          }
        }
      },
      {
        $group: {
          _id: { 
            $dateToString: { 
              format: "%d/%m", 
              date: "$createdDate" 
            } 
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { "_id": 1 }
      }
    ]);
    
   const sum = result.reduce((acc, curr) => acc + curr.count, 0);
   return { result, sum };
  } catch (error) {
    return Promise.reject(error);
  }
};

feedImpressionDbHelper.engagementDetailsByPostId = async (champhunt, feedId, userFollowerIds) => {
  try {
    const commonFilter = {
      postId: feedId,
      userId: { $in: userFollowerIds }
    };

    const [impressionCount, commentCountArray, runGivenCountArray, repostCount1] = await Promise.all([
      FeedImpression.distinct('visitedUserId', { feedId, visitedUserId: { $in: userFollowerIds } }),
      champhunt.collection('pitchComments').distinct('userId', commonFilter),
      champhunt.collection('pitchRuns').distinct('userId', commonFilter),
      champhunt.collection('pitch_ds').findOne({ _id: new Types.ObjectId(feedId) }, { sharedPost: 1 })
    ]);

    const sharedPostByFollowers = repostCount1?.sharedPost?.filter(postId => userFollowerIds.includes(postId)).length || 0;

    return {
      commentCount: commentCountArray.length,
      runGivenCount: runGivenCountArray.length,
      repostCount: sharedPostByFollowers,
      impressionCount
    };
  } catch (error) {
    return Promise.reject(error)
  }
}
feedImpressionDbHelper.engagementDetailsForPoll = async (champhunt, feedId, userFollowerIds) => {
  try {
    const [impressionCount, poll] = await Promise.all([
      FeedImpression.distinct('visitedUserId', { feedId, visitedUserId: { $in: userFollowerIds } }),

      champhunt.collection('polls').findOne({ _id: new Types.ObjectId(feedId) }, { totalVotes: 1 })
    ]);
    return { impressionCount, voteCount: poll?.totalVotes }
  } catch (error) {
    return Promise.reject(error)

  }
}
feedImpressionDbHelper.engagementDetailsForJob = async (champhunt, feedId, userFollowerIds) => {
  try {
    const commonFilter = {
      shareJobId: feedId,
      userId: { $in: userFollowerIds }
    };

    const [impressionCount, commentCount, runGivenCount] = await Promise.all([
      FeedImpression.distinct('visitedUserId', { feedId, visitedUserId: { $in: userFollowerIds } }),
      champhunt.collection('shareJobComment').distinct('userId', commonFilter),
      champhunt.collection('shareJobRuns').distinct('userId', commonFilter)
    ]);
    return { commentCount: commentCount.length, runGivenCount: runGivenCount.length, impressionCount };
  } catch (error) {
    return Promise.reject(error)

  }
}
feedImpressionDbHelper.engagementDetailsByPostIdNonFollowers = async (champhunt, feedId, userFollowerIds) => {
  try {
    const commonFilter = {
      postId: feedId,
      userId: { $nin: userFollowerIds }
    };

    const [impressionCount, commentCountArray, runGivenCountArray, repostCount1] = await Promise.all([
      FeedImpression.distinct('visitedUserId', { feedId, visitedUserId: { $nin: userFollowerIds } }),
      champhunt.collection('pitchComments').distinct('userId', commonFilter),
      champhunt.collection('pitchRuns').distinct('userId', commonFilter),
      champhunt.collection('pitch_ds').findOne({ _id: new Types.ObjectId(feedId) }, { sharedPost: 1 })
    ]);

    const sharedPostByFollowers = repostCount1?.sharedPost?.filter(postId => userFollowerIds.includes(postId)).length || 0;

    return {
      commentCount: commentCountArray.length,
      runGivenCount: runGivenCountArray.length,
      repostCount: repostCount1?.sharedPost?.length - sharedPostByFollowers,
      impressionCount
    };
  } catch (error) {
    return Promise.reject(error)
  }
}
feedImpressionDbHelper.engagementDetailsForPollNonFollowers = async (champhunt, feedId, userFollowerIds) => {
  try {
    const impressionCount = await
      FeedImpression.distinct('visitedUserId', { feedId, visitedUserId: { $nin: userFollowerIds } })

    return { impressionCount }
  } catch (error) {
    return Promise.reject(error)

  }
}
feedImpressionDbHelper.engagementDetailsForJobNonFollowers = async (champhunt, feedId, userFollowerIds) => {
  try {
    const commonFilter = {
      shareJobId: feedId,
      userId: { $nin: userFollowerIds }
    };

    const [impressionCount, commentCount, runGivenCount] = await Promise.all([
      FeedImpression.distinct('visitedUserId', { feedId, visitedUserId: { $nin: userFollowerIds } }),
      champhunt.collection('shareJobComment').distinct('userId', commonFilter),
      champhunt.collection('shareJobRuns').distinct('userId', commonFilter)
    ]);
    return { commentCount: commentCount.length, runGivenCount: runGivenCount.length, impressionCount };
  } catch (error) {
    return Promise.reject(error)

  }
}
feedImpressionDbHelper.getEngagementFromFollowers = async (feedId, uId, type) => {
  try {
    const client = await mongoclient.getClient(process.env.COMMON_HOST);
    const champhunt = client.db(process.env.DB_NAME);
    const id = new Types.ObjectId(uId);
    const followersResult = await champhunt.collection('users').findOne({ _id: id }, { followers: 1 });
    const userFollowerIds = followersResult?.followers?.map(item => item.followerUserId) || [];
    if (type === 'post') {
      return this.engagementDetailsByPostId(champhunt, feedId, userFollowerIds);
    }
    else if (type === 'poll') {

      return this.engagementDetailsForPoll(champhunt, feedId, userFollowerIds)
    }
    else if (type === 'sharejob') {
      return this.engagementDetailsForJob(champhunt, feedId, userFollowerIds)

    }
    else
      return "type does not exist"

  } catch (error) {
    return Promise.reject(error)
  }
};
feedImpressionDbHelper.getEngagementFromNonFollowers = async (feedId, uId, type) => {
  try {
    const client = await mongoclient.getClient(process.env.COMMON_HOST);
    const champhunt = client.db(process.env.DB_NAME);
    const id = new Types.ObjectId(uId);
    const followersResult = await champhunt.collection('users').findOne({ _id: id }, { followers: 1 });
    const userFollowerIds = followersResult?.followers?.map(item => item.followerUserId) || [];
    if (type === 'post') {
      return this.engagementDetailsByPostIdNonFollowers(champhunt, feedId, userFollowerIds);
    }
    else if (type === 'poll') {

      return this.engagementDetailsForPollNonFollowers(champhunt, feedId, userFollowerIds)
    }
    else if (type === 'sharejob') {
      return this.engagementDetailsForJobNonFollowers(champhunt, feedId, userFollowerIds)

    }
    else
      return "type does not exist"

  } catch (error) {
    return Promise.reject(error)
  }
};

feedImpressionDbHelper.getPerformanceByFeedId = async (feedId, type, startDate, endDate) => {
  try {
    const client = await mongoclient.getClient(process.env.COMMON_HOST);
    const db = client.db(process.env.DB_NAME);
    
    const getDailyCounts = async (collection, filter) => {
      return db.collection(collection).aggregate([
        { $match: filter },
        {
          $group: {
            _id: { $dateToString: { format: "%d/%m", date: "$createdDate" } },
            count: { $sum: 1 }
          }
        },
        { $sort: { "_id": 1 } }
      ]).toArray();
    };

    const getImpressionCounts = async (feedId, startDate, endDate) => {
      const startDateObj = new Date(startDate);
      const endDateObj = new Date(new Date(endDate).setDate(new Date(endDate).getDate() + 1)); // Increment end date by one day
      
      return FeedImpression.aggregate([
        {
          $match: {
            feedId,
            createdDate: { $gte: startDateObj, $lte: endDateObj }
          }
        },
        {
          $group: {
            _id: { $dateToString: { format: "%d/%m", date: "$createdDate" } },
            count: { $sum: 1 }
          }
        },
        { $sort: { "_id": 1 } }
      ]).exec();
    };

    const startDateObj = new Date(startDate);
    const endDateObj = new Date(new Date(endDate).setDate(new Date(endDate).getDate() + 1)); // Increment end date by one day

    if (type === 'post') {
      const commonFilter = {
        postId: feedId,
        createdDate: { $gte: startDateObj, $lte: endDateObj }
      };

      const [commentCounts, runCounts, repostData, impressionCounts] = await Promise.all([
        getDailyCounts('pitchcomments', commonFilter),
        getDailyCounts('pitchruns', commonFilter),
        db.collection('pitch_ds').findOne({ _id: new Types.ObjectId(feedId) }, { projection: { sharedPost: 1 } }),
        getImpressionCounts(feedId, startDateObj, endDateObj)
      ]);

      const repostCounts = repostData?.sharedPost?.map(post => ({
        date: new Date(post.createdDate).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit' }),
        count: 1
      })) || [];

      const aggregateCounts = (commentCounts, runCounts, repostCounts, impressionCounts) => {
        const countsMap = {};

        const addCounts = (countsArray) => {
          countsArray.forEach(({ _id: date, count }) => {
            if (!countsMap[date]) {
              countsMap[date] = 0;
            }
            countsMap[date] += count;
          });
        };

        addCounts(impressionCounts);
        addCounts(commentCounts);
        addCounts(runCounts);
        addCounts(repostCounts);

        return Object.keys(countsMap).sort((a, b) => {
          const [dayA, monthA] = a.split('/').map(Number);
          const [dayB, monthB] = b.split('/').map(Number);
          return new Date(2024, monthA - 1, dayA) - new Date(2024, monthB - 1, dayB);
        }).map(date => ({
          date,
          count: countsMap[date]
        }));
      };

      const result = aggregateCounts(commentCounts, runCounts, repostCounts, impressionCounts);

      return result;

    } else if (type === 'poll') {
      const impressionCount = await getImpressionCounts(feedId, startDate, endDate);
      return impressionCount.map(({ _id: date, count }) => ({ date, count }));

    } else if (type === 'sharejob') {
      const commonFilter = { shareJobId: feedId, createdDate: { $gte: startDateObj, $lte: endDateObj } };

      const [commentCounts, runCounts, impressionCounts] = await Promise.all([
        getDailyCounts('shareJobComment', commonFilter),
        getDailyCounts('shareJobRuns', commonFilter),
        getImpressionCounts(feedId, startDateObj, endDateObj)
      ]);

      const aggregateCounts = (commentCounts, runCounts, impressionCounts) => {
        const countsMap = {};

        const addCounts = (countsArray) => {
          countsArray.forEach(({ _id: date, count }) => {
            if (!countsMap[date]) {
              countsMap[date] = 0;
            }
            countsMap[date] += count;
          });
        };

        addCounts(commentCounts);
        addCounts(runCounts);
        addCounts(impressionCounts);

        return Object.keys(countsMap).sort((a, b) => {
          const [dayA, monthA] = a.split('/').map(Number);
          const [dayB, monthB] = b.split('/').map(Number);
          return new Date(2024, monthA - 1, dayA) - new Date(2024, monthB - 1, dayB);
        }).map(date => ({
          date,
          count: countsMap[date]
        }));
      };

      const result = aggregateCounts(commentCounts, runCounts, impressionCounts);

      return result;

    } else {
      throw new Error("Invalid type provided");
    }

  } catch (error) {
    console.error("Error fetching engagement data:", error);
    throw error; // Re-throw the error after logging it.
  }
};


feedImpressionDbHelper.getEngagementByFeedId = async (feedId, type, startDate, endDate) => {
  try {
    const client = await mongoclient.getClient(process.env.COMMON_HOST);
    const db = client.db(process.env.DB_NAME);

    const getDailyCounts = async (collection, filter) => {
      return db.collection(collection).aggregate([
        { $match: filter },
        {
          $group: {
            _id: {
              year: { $year: "$createdDate" },
              month: { $month: "$createdDate" },
              day: { $dayOfMonth: "$createdDate" }
            },
            count: { $sum: 1 }
          }
        },
        {
          $project: {
            _id: 0,
            date: {
              $dateFromParts: {
                year: "$_id.year",
                month: "$_id.month",
                day: "$_id.day"
              }
            },
            count: 1
          }
        },
        { $sort: { date: 1 } }
      ]).toArray();
    };

    // Ensure the dates are ISO format
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(new Date(endDate).setDate(new Date(endDate).getDate() + 1));

    // Common aggregation and handling for 'post' type
    if (type === 'post') {
      const commonFilter = {
        postId: feedId,
        createdDate: { $gte: startDateObj, $lte: endDateObj }
      };

      const [commentCounts, runCounts, repostData] = await Promise.all([
        getDailyCounts('pitchcomments', commonFilter),
        getDailyCounts('pitchruns', commonFilter),
        db.collection('pitch_ds').findOne({ _id: new Types.ObjectId(feedId) }, { projection: { sharedPost: 1 } })
      ]);

      console.log(commentCounts)
      console.log(runCounts)
      console.log(repostData)
      // Map reposts with counts (one repost per date entry)
      const repostCounts = repostData?.sharedPost?.map(post => ({
        date: new Date(post.createdDate),
        count: 1
      })) || [];

      // Aggregating the counts from comments, runs, and reposts
      const aggregateCounts = (commentCounts, runCounts, repostCounts) => {
        const countsMap = {};

        const addCounts = (countsArray) => {
          countsArray.forEach(({ date, count }) => {
            // Standardize date format to YYYY-MM-DD
            const dateString = date.toISOString().split('T')[0];
            if (!countsMap[dateString]) {
              countsMap[dateString] = 0;
            }
            countsMap[dateString] += count;
          });
        };

        // Add all the counts from the three sources
        addCounts(commentCounts);
        addCounts(runCounts);
        addCounts(repostCounts);

        // Convert the counts map to an array for output
        return Object.keys(countsMap).map(date => ({
          date,
          count: countsMap[date]
        }));
      };

      // Aggregate counts and calculate the total sum
      const result = aggregateCounts(commentCounts, runCounts, repostCounts);
      const sum = result.reduce((acc, curr) => acc + curr.count, 0);
      return { result, sum };

    } else if (type === 'poll') {
      // For 'poll' type, we are counting distinct 'visitedUserId'
      const impressionCount = await FeedImpression.distinct('visitedUserId', { feedId });
      return { impressionCount: impressionCount.length };

    } else if (type === 'sharejob') {
      const commonFilter = { shareJobId: feedId, createdDate: { $gte: startDateObj, $lte: endDateObj } };

      const [commentCounts, runCounts] = await Promise.all([
        getDailyCounts('shareJobComment', commonFilter),
        getDailyCounts('shareJobRuns', commonFilter)
      ]);

      // Aggregating the counts for 'sharejob'
      const aggregateCounts = (commentCounts, runCounts) => {
        const countsMap = {};

        const addCounts = (countsArray) => {
          countsArray.forEach(({ date, count }) => {
            // Standardize date format to YYYY-MM-DD
            const dateString = date.toISOString().split('T')[0];
            if (!countsMap[dateString]) {
              countsMap[dateString] = 0;
            }
            countsMap[dateString] += count;
          });
        };

        addCounts(commentCounts);
        addCounts(runCounts);

        return Object.keys(countsMap).map(date => ({
          date,
          count: countsMap[date]
        }));
      };

      const result = aggregateCounts(commentCounts, runCounts);

      return result;

    } else {
      throw new Error("Invalid type provided");
    }

  } catch (error) {
    console.error("Error fetching engagement data:", error);
    throw error; // Re-throw the error after logging it.
  }
};


feedImpressionDbHelper.runsReceivedByUserId = async (_userId, startDate, endDate) => {
  let client;
  try {
    const start = new Date(startDate)
    const end = new Date(endDate)
    client = await mongoclient.getClient(process.env.COMMON_HOST);
    const db = client.db(process.env.DB_NAME);
    const contestDb = client.db(process.env.CONTEST_DB_NAME);
    const jobDb = client.db(process.env.DB_Champhunt_job)
    let _receivedRun = 0
    const user = await db.collection('users')
      .findOne({ _id: new Types.ObjectId(_userId) }, { defaultRun: 1 })


    const defaultRun = user && user.defaultRun ? user.defaultRun : [];

    if (defaultRun && defaultRun.length > 0) {
      for (let index1 = 0; index1 < defaultRun.length; index1 += 1) {
        if (defaultRun[index1].createdDate >= start && defaultRun?.createdDate <= end)
          _receivedRun = _receivedRun + defaultRun[index1].givenRun;
      }
    }
    //contest received run
    const predictionRewardOfUserId = await contestDb.collection('userpredictionquestions').find({ userId: _userId, createdDate: { $gte: start, $lte: end } }).toArray();
    if (predictionRewardOfUserId && predictionRewardOfUserId.length > 0) {
      for (let index7 = 0; index7 < predictionRewardOfUserId.length; index7 += 1) {
        _receivedRun = _receivedRun + predictionRewardOfUserId[index7].rewarded;

      }
    }
    const cointossOfUserId = await contestDb.collection('usercoindetails').find({ userId: _userId, createdDate: { $gte: start, $lte: end } }).toArray();
    if (cointossOfUserId && cointossOfUserId.length > 0) {
      for (let index5 = 0; index5 < cointossOfUserId.length; index5 += 1) {
        _receivedRun = _receivedRun + cointossOfUserId[index5].rewardedRun;
      }
    }
    const pitchOfUserId = await db.collection('pitch_ds').find({ userId: _userId, createdDate: { $gte: start, $lte: end } }).toArray();
    if (pitchOfUserId && pitchOfUserId.length > 0) {
      for (let index3 = 0; index3 < pitchOfUserId.length; index3 += 1) {
        _receivedRun = _receivedRun + pitchOfUserId[index3].postRunCount;
      }
    }

    const shareJobRunOfUserId = await jobDb.collection('sharejobs').find({ userId: new Types.ObjectId(_userId), createdDate: { $gte: start, $lte: end } }).toArray();
    if (shareJobRunOfUserId && shareJobRunOfUserId.length > 0) {
      for (let index5 = 0; index5 < shareJobRunOfUserId.length; index5 += 1) {
        _receivedRun = _receivedRun + shareJobRunOfUserId[index5].shareJobRunCount;
      }
    }
    //book cricket runs
    // const bookCricketDetailsOfUserId = await contestDb.collection('userbookcrickets').find({ userId: _userId, createdDate: { $gte: start, $lte: end } }).toArray();
    // if (bookCricketDetailsOfUserId && bookCricketDetailsOfUserId.length > 0) {
    //     for (let index5 = 0; index5 < bookCricketDetailsOfUserId.length; index5 += 1) {
    //         _receivedRun += bookCricketDetailsOfUserId[index5].rewardedRun;

    //     }
    // }


  } catch (error) {
    console.log('error', error);
  }

}

feedImpressionDbHelper.getProfileReachOfUserId = async (userId,startDate,endDate) => {
  try {
    const feeds = await Feed.find({ userId }).select('feed_id');
    const feedIds = feeds.map(feed => feed.feed_id);

    if (feedIds.length === 0) {
      return { result: [], sum: 0 };
    }
    const result = await FeedImpression.aggregate([
      {
        $match: {
          feedId: { $in: feedIds },
          createdDate: { $gte: new Date(startDate), $lte: new Date(endDate+1) }
        }
      },
      {
        $project: {
          visitedUserId: 1,
          createdDate: -1
        }
      },
      {
        $addFields: {
          date: { $dateToString: { format: "%d/%m", date: "$createdDate" } }
        }
      },
      {
        $group: {
          _id: "$date",
          uniqueVisitors: { $addToSet: "$visitedUserId" },
        },
        
      },{
        $sort: { "_id": 1 }
      }
    ]);
    const sum = result.reduce((acc, curr) => acc + curr.uniqueVisitors.length, 0);
    return {result,sum};
  } catch (error) {
    return Promise.reject(error);
  }
};

feedImpressionDbHelper.getProfileImpressionOfUserId = async (userId, startDate, endDate) => {
  try {
    // Step 1: Fetch all feedIds for the given userId from the feeds collection
    const feeds = await Feed.find({ userId }).select('feed_id');
    const feedIds = feeds.map(feed => feed.feed_id);

    if (feedIds.length === 0) {
      return { result: [], sum: 0 };
    }

    // Step 2: Aggregate impressions from the FeedImpression collection using the fetched feedIds
    const result = await FeedImpression.aggregate([
      {
        $match: {
          feedId: { $in: feedIds },
          createdDate: {
            $gte: new Date(startDate),
            $lte: new Date(new Date(endDate).setDate(new Date(endDate).getDate() + 1)) // Ensure end date is inclusive
          }
        }
      },
      {
        $group: {
          _id: { $dateToString: { format: "%d/%m", date: "$createdDate" } },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { "_id": 1 }
      }
    ]);

    const sum = result.reduce((acc, curr) => acc + curr.count, 0);

    return { result, sum };
  } catch (error) {
    return Promise.reject(error);
  }
};

feedImpressionDbHelper.getProfilePerformanceByUserId = async (userId, startDate, endDate) => {
  try {
    const client = await mongoclient.getClient(process.env.COMMON_HOST);
    const db = client.db(process.env.DB_NAME);
    const feeds = await Feed.find({ userId }).select('feed_id');
    const feedIds = feeds.map(feed => feed.feed_id);

      if (feedIds.length === 0) {
        return { result: [], sum: 0 };
      }

    const getDailyCounts = async (collection, filter) => {
      return db.collection(collection).aggregate([
        { $match: filter },
        {
          $group: {
            _id: { $dateToString: { format: "%d/%m", date: "$createdDate" } },
            count: { $sum: 1 }
          }
        },
        { $sort: { "_id": 1 } }
      ]).toArray();
    };

    const getImpressionCounts = async (feedsId, startDate, endDate) => {
      return FeedImpression.aggregate([
        {
          $match: {
            feedId:{$in:feedsId},
            createdDate: { $gte: new Date(startDate), $lte: new Date(endDate+1) }
          }
        },
        {
          $group: {
            _id: { $dateToString: { format: "%d/%m", date: "$createdDate" } },
            count: { $sum: 1 }
          }
        },
        { $sort: { "_id": 1 } }
      ]).exec();
    };

    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate+1);

      const commonFilter = {
        postId: { $in: feedIds },
        createdDate: { $gte: startDateObj, $lte: endDateObj }
      };

      const [commentCounts, runCounts, repostData, impressionCounts] = await Promise.all([
        getDailyCounts('pitchcomments', commonFilter),
        getDailyCounts('pitchruns', commonFilter),
        db.collection('pitch_ds').find({ feedId: { $in: feedIds } }, { projection: { sharedPost: 1, createdDate: 1 } }).toArray(),
        getImpressionCounts(feedIds, startDate, endDate)
      ]);

      const repostCounts = repostData?.sharedPost?.map(post => ({
        date: new Date(post.createdDate).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit' }),
        count: 1
      })) || [];

      const aggregateCounts = (commentCounts, runCounts, repostCounts, impressionCounts) => {
        const countsMap = {};

        const addCounts = (countsArray) => {
          countsArray.forEach(({ _id: date, count }) => {
            if (!countsMap[date]) {
              countsMap[date] = 0;
            }
            countsMap[date] += count;
          });
        };

        addCounts(impressionCounts);
        addCounts(commentCounts);
        addCounts(runCounts);
        addCounts(repostCounts);

        return Object.keys(countsMap).sort((a, b) => {
          const [dayA, monthA] = a.split('/').map(Number);
          const [dayB, monthB] = b.split('/').map(Number);
          return new Date(2024, monthA - 1, dayA) - new Date(2024, monthB - 1, dayB);
        }).map(date => ({
          date,
          count: countsMap[date]
        }));
      };

      const result = aggregateCounts(commentCounts, runCounts, repostCounts, impressionCounts);

      return result;


  } catch (error) {
    console.error("Error fetching engagement data:", error);
    throw error; // Re-throw the error after logging it.
  }
};


feedImpressionDbHelper.getProfileEngagement = async (userId, startDate, endDate) => {
    try {
      const client = await mongoclient.getClient(process.env.COMMON_HOST);
      const db = client.db(process.env.DB_NAME);
      
      const feeds = await Feed.find({ userId }).select('feed_id');
      const feedIds = feeds.map(feed => feed.feed_id);

      if (feedIds.length === 0) {
        return { result: [], sum: 0 };
      }

      const getDailyCounts = async (collection, filter) => {
        return db.collection(collection).aggregate([
          { $match: filter },
          {
            $group: {
              _id: {
                year: { $year: "$createdDate" },
                month: { $month: "$createdDate" },
                day: { $dayOfMonth: "$createdDate" }
              },
              count: { $sum: 1 }
            }
          },
          {
            $project: {
              _id: 0,
              date: {
                $dateFromParts: {
                  year: "$_id.year",
                  month: "$_id.month",
                  day: "$_id.day"
                }
              },
              count: 1
            }
          },
          { $sort: { date: 1 } }
        ]).toArray();
      };
  
      const startDateObj = new Date(startDate);
      const endDateObj = new Date(endDate+1);
  
        const commonFilter = {
          postId: { $in: feedIds },
          createdDate: { $gte: startDateObj, $lte: endDateObj }
        };
  
        const [commentCounts, runCounts, repostData] = await Promise.all([
          getDailyCounts('pitchcomments', commonFilter),
          getDailyCounts('pitchruns', commonFilter),
          db.collection('pitch_ds').find({ feedId: { $in: feedIds } }, { projection: { sharedPost: 1, createdDate: 1 } }).toArray()
        ]);
  
        const repostCounts = repostData?.sharedPost?.map(post => ({
          date: new Date(post.createdDate),
          count: 1
        })) || [];
  
        const aggregateCounts = (commentCounts, runCounts, repostCounts) => {
          const countsMap = {};
  
          const addCounts = (countsArray) => {
            countsArray.forEach(({ date, count }) => {
              const dateString = date.toLocaleDateString('en-GB', {
                day: '2-digit',
                month: '2-digit'
              });
              if (!countsMap[dateString]) {
                countsMap[dateString] = 0;
              }
              countsMap[dateString] += count;
            });
          };
  
          addCounts(commentCounts);
          addCounts(runCounts);
          addCounts(repostCounts);
  
          return Object.keys(countsMap).map(date => ({
            date,
            count: countsMap[date]
          }));
        };
  
        const result = aggregateCounts(commentCounts, runCounts, repostCounts);
        const sum = result.reduce((acc, curr) => acc + curr.count, 0);
        return { result, sum };
  
      
    } catch (error) {
      console.error("Error fetching engagement data:", error);
      throw error; // Re-throw the error after logging it.
    }
  };

  feedImpressionDbHelper.getProfileImpressionOfUserId = async (userId, startDate, endDate) => {
    try {
      // Step 1: Fetch all feedIds for the given userId from the feeds collection
      const feeds = await Feed.find({ userId }).select('feed_id');
      const feedIds = feeds.map(feed => feed.feed_id);
  
      if (feedIds.length === 0) {
        return { result: [], sum: 0 };
      }
  
      // Step 2: Aggregate impressions from the FeedImpression collection using the fetched feedIds
      const result = await FeedImpression.aggregate([
        {
          $match: {
            feedId: { $in: feedIds },
            createdDate: {
              $gte: new Date(startDate),
              $lte: new Date(new Date(endDate).setDate(new Date(endDate).getDate() + 1)) // Ensure end date is inclusive
            }
          }
        },
        {
          $group: {
            _id: { $dateToString: { format: "%d/%m", date: "$createdDate" } },
            count: { $sum: 1 }
          }
        },
        {
          $sort: { "_id": 1 }
        }
      ]);
  
      const sum = result.reduce((acc, curr) => acc + curr.count, 0);
  
      return { result, sum };
    } catch (error) {
      return Promise.reject(error);
    }
  };

  
  feedImpressionDbHelper.getAllFeedsImpression = async (userId, startDate, endDate) => {
    try {
      // Step 1: Fetch all feedIds and feedTypes for the given userId from the feeds collection
      const feeds = await Feed.find({ userId }).select('feed_id type');
      const feedIds = feeds.map(feed => feed.feed_id);
      const feedTypes = feeds.reduce((acc, feed) => {
        acc[feed.feed_id] = feed.type;
        return acc;
      }, {});
  
      if (feedIds.length === 0) {
        return { result: [] };
      }
  
      const startDateObj = new Date(startDate);
      const endDateObj = new Date(endDate);
      const previousStartDate = new Date(startDateObj);
      previousStartDate.setDate(startDateObj.getDate() - (endDateObj.getDate() - startDateObj.getDate() + 1));
      const previousEndDate = new Date(endDateObj);
      previousEndDate.setDate(endDateObj.getDate() - (endDateObj.getDate() - startDateObj.getDate() + 1));
  
      // Step 2: Aggregate impressions for the current date range
      const currentResult = await FeedImpression.aggregate([
        {
          $match: {
            feedId: { $in: feedIds },
            createdDate: {
              $gte: startDateObj,
              $lte: new Date(endDateObj.setDate(endDateObj.getDate() + 1)) // Ensure end date is inclusive
            }
          }
        },
        {
          $group: {
            _id: "$feedId",
            count: { $sum: 1 }
          }
        }
      ]);

  
      // Step 3: Aggregate impressions for the previous date range
      const previousResult = await FeedImpression.aggregate([
        {
          $match: {
            feedId: { $in: feedIds },
            createdDate: {
              $gte: previousStartDate,
              $lte: new Date(previousEndDate.setDate(previousEndDate.getDate() + 1)) // Ensure end date is inclusive
            }
          }
        },
        {
          $group: {
            _id: "$feedId",
            count: { $sum: 1 }
          }
        }
      ]);
  
      // Step 4: Calculate the rate of change for each feedId
      const previousCounts = previousResult.reduce((acc, { _id, count }) => {
        acc[_id] = count;
        return acc;
      }, {});
  
      const result = currentResult.map(({ _id, count }) => {
        const previousCount = previousCounts[_id] || 0;
        const rate = previousCount === 0 ? (count === 0 ? 0 : 100) : ((count - previousCount) / previousCount) * 100;
        return { feedId: _id, feedType: feedTypes[_id], count, rate };
      });
  
      return result;
    } catch (error) {
      return Promise.reject(error);
    }
  };
  

module.exports = feedImpressionDbHelper;
