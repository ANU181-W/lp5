
const feedDbHelper = require('../feedfolder/dbHelper');
const dbHelper = require('./dbHelper');
const viewModel = require('./viewModel');

const feedImpressionController = {};

feedImpressionController.create = async (
  req
) => {
  try {
    const { userid, username } = req.headers

    const { feedId } = req.body
    if (userid && username && feedId) {
      const createViewModel = viewModel.createViewModel(
        req
      );
      const res = await dbHelper.save(createViewModel);
      if (res) {
        feedDbHelper.updateImpression(feedId, res?.impressionCount);

      }
      return res;
    }
    return 'input required';
  } catch (err) {
    return Promise.reject(err);
  }
};

feedImpressionController.getImpressionOfFeedId = async (req) => {
  try {
    return await dbHelper.getImpressionOfFeedId(req.params.feedId);
  } catch (err) {
    return Promise.reject(err);
  }
};

feedImpressionController.getReachOfFeedId = async (req) => {
  try {
    return await dbHelper.getReachOfFeedId(req.params.feedId,req.params.startDate,req.params.endDate);
  } catch (err) {
    return Promise.reject(err);
  }
};


feedImpressionController.getImpressionOfFeedIdByDate = async (req) => {
  try {
    return await dbHelper.getImpressionOfFeedIdByDate(req.params.feedId, req.params.startDate, req.params.endDate);
  } catch (err) {
    return Promise.reject(err);
  }
};

feedImpressionController.getEngagementFromFollowers = async (req) => {
  try {
    return await dbHelper.getEngagementFromFollowers(req.params.feedId, req.params.userId, req.params.type)
  } catch (error) {
    return Promise.reject(error);
  }
}

feedImpressionController.getEngagementFromNonFollowers = async (req) => {
  try {
    return await dbHelper.getEngagementFromNonFollowers(req.params.feedId, req.params.userId, req.params.type)
  } catch (error) {
    return Promise.reject(error);
  }
}

feedImpressionController.runsReceivedByUserId = async (req) => {
  try {
    return await dbHelper.runsReceivedByUserId(req.params.userId, req.params.startDate, req.params.endDate);
  } catch (error) {
    return Promise.reject(error)
  }
}

feedImpressionController.getEngagementByFeedId = async (req) => {
  try {
    return await dbHelper.getEngagementByFeedId(req.params.feedId,req.params.type,req.params.startDate, req.params.endDate);
  } catch (error) {
    return Promise.reject(error)
  }
}

feedImpressionController.getPerformanceByFeedId = async (req) => {
  try {
    return await dbHelper.getPerformanceByFeedId(req.params.feedId,req.params.type,req.params.startDate, req.params.endDate);
  } catch (error) {
    return Promise.reject(error)
  }
}

feedImpressionController.getProfileEngagement = async (req) => {
  try {
    return await dbHelper.getProfileEngagement(req.params.userId,req.params.startDate, req.params.endDate);
  } catch (error) {
    return Promise.reject(error)
  }
}

feedImpressionController.getProfilePerformanceByUserId = async (req) => {
  try {
    return await dbHelper.getProfilePerformanceByUserId(req.params.userId,req.params.startDate, req.params.endDate);
  } catch (error) {
    return Promise.reject(error)
  }
}

feedImpressionController.getProfileImpressionOfUserId = async (req) => {
  try {
    return await dbHelper.getProfileImpressionOfUserId(req.params.userId, req.params.startDate, req.params.endDate);
  } catch (err) {
    return Promise.reject(err);
  }
};

feedImpressionController.getProfileReachOfUserId = async (req) => {
  try {
    return await dbHelper.getProfileReachOfUserId(req.params.userId,req.params.startDate,req.params.endDate);
  } catch (err) {
    return Promise.reject(err);
  }
};

feedImpressionController.getFeedAndImpression = async (req) => {
  try {
    return await dbHelper.getFeedAndImpression(req.params.userId,req.params.startDate,req.params.endDate);
  } catch (err) {
    return Promise.reject(err);
  }
};

feedImpressionController.getAllFeedsImpression = async (req) => {
  try {
    return await dbHelper.getAllFeedsImpression(req.params.userId,req.params.startDate,req.params.endDate);
  } catch (err) {
    return Promise.reject(err);
  }
};


module.exports = feedImpressionController;
