const { BASE_URL_SQS } = process.env;
const feedDbHelper = require('../feedfolder/dbHelper');
const sqsHelper = require('./sqsHelper');

const helper = {};

helper.handleMessage = async (queueUrl, msg) => {
  const data = JSON.parse(msg.Body);
  const supportedQueues = [
    `${BASE_URL_SQS}UPDATEPITCHINFEED.fifo`,
    `${BASE_URL_SQS}UPDATEPOLLINFEED.fifo`,
    `${BASE_URL_SQS}UPDATESHAREJOBINFEED.fifo`,
    `${BASE_URL_SQS}UPDATECHALLENGEINFEED.fifo`,
  ];

  try {
    if (supportedQueues.includes(queueUrl)) {
      const ar = await feedDbHelper.createFeed(data);
      console.log("ar", ar)
      return 'db updated';
    } else {
      throw new Error('No queue found');
    }
  } catch (err) {
    const error = { data, queueUrl, createdDate: new Date() };
    sqsHelper.send(`${BASE_URL_SQS}ERROR_QUEUE.fifo`, error, 'err-group');
    console.log(err);
    return Promise.reject(err);
  }
};

module.exports = helper;
