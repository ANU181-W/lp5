const { Consumer } = require('sqs-consumer');
const { SQSClient } = require('@aws-sdk/client-sqs');
const helper = require('./helper');

const { BASE_URL_SQS } = process.env;

const consumer = {};

consumer.start = () => {
  console.log('sqs starting consuming');
  const queues = [
    'UPDATEPITCHINFEED.fifo',
    'UPDATEPOLLINFEED.fifo',
    'UPDATESHAREJOBINFEED.fifo',
    'UPDATECHALLENGEINFEED.fifo',

  ];
  for (let index = 0; index < queues.length; index += 1) {
    const queqeName = queues[index];
    consumer.consume(`${BASE_URL_SQS}${queqeName}`);
  }
};

consumer.consume = (queueUrl) => {
  const app = Consumer.create({
    queueUrl,
    handleMessage: async (msg) => {
      console.log({ queueUrl, msg });
      helper.handleMessage(queueUrl, msg);
    },
    sqs: new SQSClient({
      region: process.env.SQS_REGION,
      credentials: {
        accessKeyId: process.env.SQS_ACCESS_KEY_ID,
        secretAccessKey: process.env.SQS_SECRET_ACCESS_KEY,
      },
    }),
    //   batchSize: 10,
    //   waitTimeSeconds: 20, // Long polling
  });

  app.on('error', (err) => {
    console.error({ queueUrl }, err.message);
  });

  app.on('processing_error', (err) => {
    console.error({ queueUrl }, err.message);
  });

  app.on('timeout_error', (err) => {
    console.error({ queueUrl }, err.message);
  });

  app.start();
};

module.exports = consumer;
