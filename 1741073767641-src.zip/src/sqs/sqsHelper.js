// const sqs = require('./sqsClient');
const AWS = require('aws-sdk');

AWS.config.update({
  region: process.env.SQS_REGION,
  accessKeyId: process.env.SQS_ACCESS_KEY_ID,
  secretAccessKey: process.env.SQS_SECRET_ACCESS_KEY,
});

// Set up SQS client
const sqs = new AWS.SQS({ apiVersion: '2012-11-05' });
const sqsHelper = {};
sqsHelper.send = async (queueUrl, data, groupId) => {
  console.log({ queueUrl, groupId });
  const sendParams = {
    MessageGroupId: groupId,
    MessageDeduplicationId: new Date().toJSON(),
    MessageBody: JSON.stringify(data),
    QueueUrl: queueUrl,
  };
  return sqs.sendMessage(sendParams).promise();
};

module.exports = sqsHelper;
