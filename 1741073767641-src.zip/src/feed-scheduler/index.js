
const mongoClient = require('../../mongodbConnection');
const feedModel = require('../feedfolder/model');
const FeedScheduler = {};
FeedScheduler.createNewEntry = async (COMMON_HOST, DB_NAME) => {
  let client;
  try {
    client = await mongoClient.getClient(COMMON_HOST);
    const champhunt = client.db(DB_NAME);
    const champhuntjob = client.db(process.env.DB_Champhunt_job);

    if (global.myGlobalValue) {
      console.log('out')
      return;
    }
    // global.myGlobalValue = true;
    const limit = 100;
    let skip = 0;
    while (skip >= 0) {
      // console.log('in')
      let currentDate = new Date();
      currentDate.setSeconds(currentDate.getSeconds() + 100);


      // post data 
      const posts = await champhunt.collection('pitch_ds')
        .find({
          $or: [{ processed: false }, { processed: { $exists: false } }],
          createdDate: { $lte: currentDate }
        })
        .sort({ createdDate: -1 })
        .skip(skip)
        .limit(limit)
        .toArray()
        .then(posts => posts.map(({ _id, ...rest }) => ({ feed_id: _id, ...rest, type: 'post' })));


      // poll data
      const polls = await champhunt.collection('polls')
        .find({
          $or: [{ processed: false }, { processed: { $exists: false } }],
          createdDate: { $lte: currentDate }
        })
        .sort({ createdDate: -1 })
        .skip(skip)
        .limit(limit)
        .toArray()
        .then(polls => polls.map(({ _id, ...rest }) => ({ feed_id: _id, ...rest, type: 'poll' })));


      // jobData 

      const sharejobs = await champhuntjob.collection('sharejobs')
        .find({
          $or: [{ processed: false }, { processed: { $exists: false } }],
          createdDate: { $lte: currentDate }
        })
        .sort({ createdDate: -1 })
        .skip(skip)
        .limit(limit)
        .toArray()
        .then(sharejobs => sharejobs.map(({ _id, ...rest }) => ({ feed_id: _id, ...rest, type: 'sharejob' })));

      // addding all data in one collection 
      const feedData = [...posts, ...polls, ...sharejobs]

      // if feedData is not empty then i wil do this operation
      if (feedData.length > 0) {
        let postupdate, pollupdate, jobsupdate = [];
        console.log(posts)
        const postIds = await posts?.map(obj => obj.feed_id);
        const pollIds = await polls?.map(obj => obj.feed_id);
        const jobIds = await sharejobs?.map(obj => obj.feed_id);

        feedData.forEach(async (data) => {

          if (data?.feed_id) {
            // Update the object in feedModel if it has a feed_id
            await feedModel.updateOne({ feed_id: data.feed_id }, { $set: { ...data } }, { upsert: true });
          }
        });
        if (postIds.length > 0) {
          postupdate = champhunt.collection('pitch_ds').updateMany({ _id: { $in: postIds } }, { $set: { processed: true } });
        }
        if (pollIds.length > 0) {
          pollupdate = champhunt.collection('polls').updateMany({ _id: { $in: pollIds } }, { $set: { processed: true } });
        }
        if (jobIds.length > 0) {
          jobsupdate = champhuntjob.collection('sharejobs').updateMany({ _id: { $in: jobIds } }, { $set: { processed: true } });
        }
        await Promise.all([postupdate, pollupdate, jobsupdate])
      } else {
        global.myGlobalValue = false;
        break;
      }
      global.myGlobalValue = true;

      skip += limit;
    }

  } catch (error) {
    console.log('error', error);
  }

}

module.exports = FeedScheduler;




