const { MongoClient } = require('mongodb');

// const dbOptions = {
//   useNewUrlParser: true,
//   connectTimeoutMS: 45000, // Give up initial connection after 45 seconds
//   socketTimeoutMS: 60000, // Close sockets after 60 seconds of inactivity
//   family: 4, // Use IPv4, skip trying IPv6
//   useUnifiedTopology: true,
//   keepAlive: true,
//   keepAliveInitialDelay: 300000,
//   maxPoolSize: 200,
// };
let cachedClient = null;
const connect = async (uri) => {
  if (cachedClient) {
    // If a connection already exists, return the cached client
    console.log('Using existing MongoDB connection');
    return cachedClient;
  }
  const _client = new MongoClient(uri);

  try {
    cachedClient = await _client.connect(); // Cache the client object for future use
    return cachedClient;
  } catch (error) {
    console.error('Error connecting to MongoDB', error);
    throw error;
  }
};

const getClient = async (uri) => connect(uri);

module.exports = {
  getClient,
};
