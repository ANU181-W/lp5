const express = require("express");
const mongoose = require("mongoose");
const bluebird = require("bluebird");
const dotenv = require("dotenv");
const nodeAbortController = require("node-abort-controller");
const feedRouter = require('./src/feedfolder/route')
const feedImpressionRouter = require('./src/feed-impression/route')
global.AbortController = nodeAbortController.AbortController;

// const helper = require("./helper");

const app = express();
global.myGlobalValue = false;
const enviroment = process.argv[2] || "development";
dotenv.config({
    path: `${__dirname}/config/.env.${enviroment}`,
    node_env: process.argv[2] || "development",
});
// const { COMMON_HOST, DB_NAME } = process.env;

// const logger = require("./config/serviceLogger");
const consumer = require("./src/sqs/consumer");
// const FeedScheduler = require("./src/feed-scheduler");
// const { consume } = require("./sqs/consumer");

const dbOptions = {
    useNewUrlParser: true,
    autoIndex: false, // Don't build indexes
    connectTimeoutMS: 45000, // Give up initial connection after 45 seconds
    socketTimeoutMS: 60000, // Close sockets after 60 seconds of inactivity
    family: 4, // Use IPv4, skip trying IPv6
    useUnifiedTopology: true,
    //keepAlive: true,
    //keepAliveInitialDelay: 300000,
    maxPoolSize: 200,

};
bluebird.promisifyAll(mongoose);
mongoose.connect(process.env.DB_HOST, dbOptions);

app.use(express.json());
const { GATEWAY_URL } = process.env;
const callingAPIAuthenticationMiddleware = (req, res, next) => {
    if (
        req.url === "/" ||
        req.headers.callingurl === GATEWAY_URL ||
        req.url.toLowerCase().includes("report")
    ) {
        return next();
    }
    return res.status(500).json("Not Allow");
};

// scheduleJob("* * * * * *", async () => {
//     console.log('-------feedsScheduler started------');
//     console.log(COMMON_HOST, DB_NAME);
//     await FeedScheduler.createNewEntry(COMMON_HOST, DB_NAME);
//     console.log('-------feedsScheduler ended------');
// })

app.use(callingAPIAuthenticationMiddleware);
app.use('/', feedRouter);
app.use('/feedimpression', feedImpressionRouter);

// app.use((err, req, res) => {
// logger.saveError("mongodb", err);
// helper.saveErrorInAws(err);
// return res.status(err.status || err.statusCode || 500).send(err.message);
// });

app.listen(process.env.PORT, () => {
    console.log(`Feed is Listening to Port ${process.env.PORT}`);
});

consumer.start();


