const { createLogger, transports, format } = require('winston');
require('winston-daily-rotate-file');
const fsObj = require('fs');
const { S3StreamLogger } = require('s3-streamlogger');

let bucketName = 'champhunt-api-logs';

const logger = (logFolder) => {
  const s3Stream = new S3StreamLogger({
    bucket: bucketName,
    folder: logFolder,
    access_key_id: process.env.AWS_ACCESS_KEY_ID,
    secret_access_key: process.env.AWS_SECRET_ACCESS_KEY,
  });

  const s3transport = new transports.Stream({
    stream: s3Stream,
  });

  s3transport.on('error', () => {
    // console.log('----error------', err);
  });
  return createLogger({
    transports: [s3transport],
  });
};

const localSystemLogger = (logFolder) => {
  const env = process.env.NODE_ENV || 'dev';
  const logDir = 'log';

  if (!fsObj.existsSync(logDir)) {
    fsObj.mkdirSync(logDir);
  }
  if (!fsObj.existsSync(logFolder)) {
    fsObj.mkdirSync(logFolder);
  }

  const dailyRotateFileTransport = new transports.DailyRotateFile({
    filename: `${logDir}/${logFolder}/%DATE%-results.log`,
    datePattern: 'YYYY-MM-DD',
  });

  return createLogger({
    level: env === 'dev' ? 'verbose' : 'info',
    format: format.combine(
      format.timestamp({
        format: 'YYYY-MM-DD HH:mm:ss',
      }),
      format.printf(
        (info) => `${info.timestamp} ${info.level}: ${info.message}`
      )
    ),
    transports: [
      new transports.Console({
        level: 'info',
        format: format.combine(
          format.colorize(),
          format.printf(
            (info) => `${info.timestamp} ${info.level}: ${info.message}`
          )
        ),
      }),
      dailyRotateFileTransport,
    ],
  });
};

const apiLogger = {};
apiLogger.info = (logFolder, data) => {
  if (process.env.NODE_ENV === 'development')
    bucketName = 'champhunt-dev-api-logs';
  const log = data;
  log.environment = process.env.NODE_ENV;
  log.date = new Date().toLocaleString();
  logger(logFolder).info(log);

  // For consolidated logs
  log.folder = logFolder;
  logger('all').info(log);
};
apiLogger.error = (logFolder, err) => {
  logger(logFolder).error(err);
};

apiLogger.saveErrorInLocalSystem = (logFolder, api) => {
  localSystemLogger(logFolder).info(api);
};

// logger('test').info('Hello Winston!');

module.exports = apiLogger;
