const reactPlugin = require('eslint-plugin-react');

module.exports = [
  {
    files: ['*.js', '*.jsx'],
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
    },
    plugins: {
      react: reactPlugin,
    },
    rules: {},
  },
];